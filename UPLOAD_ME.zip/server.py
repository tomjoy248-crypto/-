#!/usr/bin/env python3
"""漏洞哨兵 V7 - 真实响应头扫描服务"""

import json
import ssl
import urllib.request
import urllib.error
from datetime import datetime
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path

import os
HOST = "0.0.0.0"
PORT = int(os.environ.get("PORT", 8000))


def real_scan(raw_url):
    """真实响应头扫描。"""
    url = raw_url.strip()
    if not url.startswith("http://") and not url.startswith("https://"):
        url = "https://" + url
    
    req = urllib.request.Request(
        url,
        headers={
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        },
        method="HEAD",
    )
    
    try:
        resp = urllib.request.urlopen(req, timeout=8, context=ssl._create_unverified_context())
        headers = {k.lower(): v for k, v in dict(resp.headers).items()}
        final_url = resp.geturl()
    except urllib.error.HTTPError as e:
        headers = {k.lower(): v for k, v in dict(e.headers).items()}
        final_url = url
    except Exception as e:
        return {"error": str(e)}
    
    is_https = final_url.startswith("https://")
    findings = []
    
    if not is_https:
        findings.append({"name": "未启用 HTTPS", "level": "高风险", "owasp": "A02 加密机制失效",
            "summary": "网站使用 HTTP 明文传输，存在中间人攻击风险。",
            "fix": "配置 SSL 证书并启用 HTTPS 强制跳转。",
            "ai_advice": "所有现代网站都应使用 HTTPS。建议申请 Let's Encrypt 免费证书。"})
    
    if not headers.get("strict-transport-security") and is_https:
        findings.append({"name": "缺少 HSTS 响应头", "level": "中风险", "owasp": "A05 安全配置错误",
            "summary": "HTTPS 网站未配置 HSTS，用户可能通过 HTTP 访问。",
            "fix": "添加 Strict-Transport-Security 响应头。",
            "ai_advice": "HSTS 强制浏览器使用 HTTPS，防止 SSL 剥离攻击。建议配置 max-age=31536000。"})
    
    if not headers.get("content-security-policy"):
        findings.append({"name": "缺少 Content-Security-Policy", "level": "中风险", "owasp": "A03 注入攻击",
            "summary": "未配置内容安全策略，存在 XSS 和数据注入风险。",
            "fix": "配置 CSP 响应头，限制资源加载来源。",
            "ai_advice": "CSP 是防御 XSS 的关键手段。建议从 default-src 'self' 开始，逐步细化。"})
    
    if not headers.get("x-frame-options"):
        findings.append({"name": "缺少 X-Frame-Options", "level": "低风险", "owasp": "A05 安全配置错误",
            "summary": "未配置点击劫持防护，页面可能被嵌入恶意 iframe。",
            "fix": "添加 X-Frame-Options: DENY 或 SAMEORIGIN。",
            "ai_advice": "点击劫持攻击可诱导用户点击隐藏按钮。X-Frame-Options 是最简单的防护。"})
    
    if not headers.get("x-content-type-options"):
        findings.append({"name": "缺少 X-Content-Type-Options", "level": "低风险", "owasp": "A05 安全配置错误",
            "summary": "浏览器可能通过 MIME 嗅探执行恶意文件。",
            "fix": "添加 X-Content-Type-Options: nosniff。",
            "ai_advice": "nosniff 防止浏览器将无害文件类型解释为可执行脚本。"})
    
    if not headers.get("referrer-policy"):
        findings.append({"name": "缺少 Referrer-Policy", "level": "低风险", "owasp": "A05 安全配置错误",
            "summary": "Referer 信息可能泄露用户隐私和内部 URL 结构。",
            "fix": "添加 Referrer-Policy: strict-origin-when-cross-origin。",
            "ai_advice": "控制 Referer 泄露范围，保护用户隐私和内部 URL 结构。"})
    
    server = headers.get("server", "")
    if server and len(server) > 3 and not any(x in server.lower() for x in ["cloudflare", "fastly", "akamai"]):
        findings.append({"name": "服务器信息暴露", "level": "低风险", "owasp": "A05 安全配置错误",
            "summary": f"Server 头暴露具体版本信息: {server}",
            "fix": "隐藏 Server 响应头。",
            "ai_advice": "暴露服务器版本会降低攻击者侦察成本。建议隐藏或使用通用名称。"})
    
    acao = headers.get("access-control-allow-origin", "")
    if acao == "*":
        findings.append({"name": "CORS 允许任意来源", "level": "中风险", "owasp": "A01 访问控制失效",
            "summary": "CORS 配置为 *，允许任意网站跨域访问。",
            "fix": "限制为特定域名。",
            "ai_advice": "通配符 CORS 配置可能导致敏感数据泄露。建议白名单化。"})
    
    score = 100
    for f in findings:
        if f["level"] == "高风险": score -= 18
        elif f["level"] == "中风险": score -= 10
        elif f["level"] == "低风险": score -= 4
    score = max(10, min(98, score))
    risk_level = "低风险" if score >= 80 else "中风险" if score >= 60 else "高风险"
    
    return {
        "url": final_url,
        "time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "score": score,
        "risk_level": risk_level,
        "scan_mode": "real",
        "ai_report": {
            "summary": f"真实响应头扫描完成。发现 {len(findings)} 个问题，评分 {score} 分。",
            "priority": "优先修复 HSTS 和 CSP 问题。",
            "boundary": "基于真实 HTTP 响应头分析，不涉及渗透测试。",
        },
        "owasp_coverage": [
            {"category": "A01 访问控制失效", "status": "通过", "count": 0, "note": "基于响应头分析"},
            {"category": "A02 加密机制失效", "status": "通过" if is_https else "高风险", "count": 0, "note": "基于响应头分析"},
            {"category": "A03 注入攻击", "status": "通过" if headers.get("content-security-policy") else "中风险", "count": 0, "note": "基于响应头分析"},
            {"category": "A04 不安全设计", "status": "通过", "count": 0, "note": "基于响应头分析"},
            {"category": "A05 安全配置错误", "status": "通过" if len([f for f in findings if "A05" in f["owasp"]]) < 2 else "中风险", "count": 0, "note": "基于响应头分析"},
            {"category": "A06 过时组件", "status": "需深度检测", "count": 0, "note": "需依赖扫描"},
            {"category": "A07 认证失败", "status": "通过", "count": 0, "note": "基于响应头分析"},
            {"category": "A08 软件完整性", "status": "通过", "count": 0, "note": "基于响应头分析"},
            {"category": "A09 日志监控不足", "status": "需深度检测", "count": 0, "note": "需日志分析"},
            {"category": "A10 服务端请求伪造", "status": "通过", "count": 0, "note": "基于响应头分析"},
        ],
        "findings": findings,
        "raw_headers": dict(headers),
    }


class Handler(BaseHTTPRequestHandler):
    def log_message(self, fmt, *args):
        pass

    def _send_json(self, data, code=200):
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(json.dumps(data, ensure_ascii=False).encode())

    def _send_html(self, html, code=200):
        self.send_response(code)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.end_headers()
        self.wfile.write(html.encode("utf-8"))

    def do_GET(self):
        if self.path == "/" or self.path == "/index.html":
            html = Path(__file__).with_name("index.html").read_text(encoding="utf-8")
            self._send_html(html)
            return
        self.send_error(404)

    def do_POST(self):
        if self.path == "/api/scan":
            try:
                length = int(self.headers.get("Content-Length", "0"))
                payload = json.loads(self.rfile.read(length).decode("utf-8"))
                url = payload.get("url", "").strip()
                authorized = payload.get("authorized", False)
                if not authorized:
                    self._send_json({"error": "请先确认授权"}, 400)
                    return
                result = real_scan(url)
                if "error" in result:
                    self._send_json({"error": result["error"]}, 500)
                    return
                self._send_json(result)
            except Exception as e:
                self._send_json({"error": str(e)}, 500)
            return
        self.send_error(404)


if __name__ == "__main__":
    server = HTTPServer((HOST, PORT), Handler)
    print(f"漏洞哨兵 V7 已启动：http://localhost:{PORT}")
    print("按 Ctrl+C 停止服务")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\n服务已停止")
